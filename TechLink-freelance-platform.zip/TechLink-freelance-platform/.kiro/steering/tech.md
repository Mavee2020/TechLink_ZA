# Technology Stack

## Extension Platform

- VSCode/Cursor extension
- Compatible with Claude Code integration

## Configuration

- JSON-based configuration (`config.json`)
- Markdown documentation format
- Support for multiple language ecosystems

## Supported Build Systems

The extension recognizes and includes configuration files for:

- **JavaScript/Node**: package.json, .npmrc, .eslintrc.*, .prettierrc, .babelrc
- **Java**: build.gradle, settings.gradle, gradle.properties, pom.xml
- **Python**: requirements.txt, Pipfile
- **Ruby**: Gemfile
- **PHP**: composer.json
- **C/C++**: Makefile, CMakeLists.txt
- **General**: .editorconfig, .dockerignore, .gitattributes, .stylelintrc

## Common Patterns

### File Exclusions

The project excludes common build artifacts, dependencies, and binary files:
- Build outputs: `dist`, `build`, `target`, `coverage`
- Dependencies: `node_modules`, `__pycache__`
- IDE files: `.idea`, `.vscode`, `*.iml`
- Binary files: images, videos, databases, archives, executables
- Lock files: `*.lock`
- Environment files: `.env`, `.env.*`

### File Inclusions

Configuration and build files are explicitly included even if they might match exclusion patterns.

## Development Workflow

The project uses Claude Code's spec-driven development methodology:
1. Requirements gathering (EARS format)
2. Design document creation
3. Task planning and implementation
4. Iterative refinement with user approval at each stage
