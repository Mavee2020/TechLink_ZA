# Project Structure

## Directory Organization

```
.
├── .claude/                    # Claude Code integration
│   ├── agents/                 # Agent configurations
│   │   └── kfc/               # KFC agent setup
│   ├── settings/              # Claude settings
│   │   └── kfc-settings.json  # Path and view configurations
│   └── system-prompts/        # Workflow definitions
│       └── spec-workflow-starter.md
│
├── .kiro/                     # Kiro AI assistant configuration
│   └── steering/              # AI guidance documents
│
└── .snapshots/                # Snapshot templates and config
    ├── config.json            # Inclusion/exclusion patterns
    ├── readme.md              # Snapshot documentation
    └── sponsors.md            # Sponsorship information
```

## Key Configuration Files

### .snapshots/config.json

Central configuration for snapshot generation:
- `excluded_patterns`: Files/folders to ignore
- `included_patterns`: Files to always include
- `default`: Default snapshot settings

### .claude/settings/kfc-settings.json

Claude Code configuration:
- Defines paths for specs, steering, and settings
- Controls visibility of different views (specs, steering, MCP, hooks)

## Conventions

- Use kebab-case for feature names in specs (e.g., `user-authentication`)
- Markdown format for all documentation and snapshots
- JSON for configuration files
- Spec documents follow a three-phase workflow: requirements → design → tasks
