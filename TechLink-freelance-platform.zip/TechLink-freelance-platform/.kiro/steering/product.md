# Product Overview

Snapshots for AI is a VSCode/Cursor extension that helps developers create structured code snapshots for AI interactions. The tool captures relevant code context, project structure, and prompts in markdown format, making it easier to share codebases with AI assistants.

## Core Features

- Generate markdown snapshots of code files with project structure
- Configurable file inclusion/exclusion patterns
- Support for multiple build systems and project types
- Integration with Claude Code spec-driven development workflow

## Target Users

Developers who frequently interact with AI coding assistants and need to provide structured code context efficiently.
